# 19_F103_ST7735_SPI
Display text and number in real time. STM32F103 and ST7735 TFT LCD
